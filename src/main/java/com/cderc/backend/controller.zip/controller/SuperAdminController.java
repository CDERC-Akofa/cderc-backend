package com.cderc.backend.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/super-admin")
public class SuperAdminController {
    @GetMapping("/test")
    public String test() {
        return "SUPER_ADMIN works";
    }
}
